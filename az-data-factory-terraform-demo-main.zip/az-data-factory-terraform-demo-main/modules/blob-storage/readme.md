# Blob Storage Module
This module is responsible for setting up the following resources:
- storage account
- blob storage container
- the 4 blobs for the data: projects, leads, geo, expenses